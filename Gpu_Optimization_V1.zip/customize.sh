#Print welcome message
ui_print "- Enabling GPU tweaks"
ui_print "- By Fauzann"
